import java.util.*;  
public class restudent{
	
	public static void main(String[] args){
		order.addFood(new food(1, "mouse",10 ));
		order.addFood(new food(2, "keyboard",200 ));
		order.addFood(new food(3, "wair",300 ));
		order.addFood(new food(4, "light",400));
		order.addFood(new food(5, "fan",500 ));
		order.addFood(new food(6, "cigar",600 ));
		order.addFood(new food(7, "fuska",700 ));
		order.addFood(new food(8, "moneybag",800 ));
		order.addFood(new food(9, "chips",900 ));
		order.addFood(new food(10, "clock",1000));

		order.start();
		
	}

	
}